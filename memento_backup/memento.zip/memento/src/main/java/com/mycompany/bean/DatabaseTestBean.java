package com.mycompany.bean;

import com.mycompany.util.DatabaseUtil;
import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Named;

@Named
@ViewScoped
public class DatabaseTestBean implements Serializable {
    private String message;

    public void testConnection() {
        try (Connection connection = DatabaseUtil.getConnection()) {
            String query = "SELECT * FROM test_table";
            try (PreparedStatement stmt = connection.prepareStatement(query);
                 ResultSet rs = stmt.executeQuery()) {
                StringBuilder sb = new StringBuilder();
                while (rs.next()) {
                    sb.append(rs.getInt("id")).append(": ").append(rs.getString("name")).append("<br>");
                }
                message = sb.toString();
            }
        } catch (SQLException e) {
            message = "Error: " + e.getMessage();
        }
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}