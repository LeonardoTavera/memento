package com.mycompany.bean;

import com.mycompany.util.DatabaseUtil;
import jakarta.enterprise.context.SessionScoped;
import jakarta.faces.context.FacesContext;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import jakarta.servlet.http.HttpSession;
import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

@Named("commentBean")
@SessionScoped
public class CommentBean implements Serializable {
    private static final Logger LOGGER = Logger.getLogger(CommentBean.class.getName());

    private int id;
    private int forumId;
    private String text;
    private List<CommentBean> comments;
    private Timestamp createdAt;
    private String username; // Asegúrate de que esta propiedad esté aquí

    @Inject
    private UserBean userBean;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getForumId() {
        return forumId;
    }

    public void setForumId(int forumId) {
        this.forumId = forumId;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public List<CommentBean> getComments() {
        return comments;
    }

    public void setComments(List<CommentBean> comments) {
        this.comments = comments;
    }

    public Timestamp getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void createComment() {
        try (Connection connection = DatabaseUtil.getConnection()) {
            String sql = "INSERT INTO comments (forum_id, username, text, created_by) VALUES (?, ?, ?, ?)";
            try (PreparedStatement stmt = connection.prepareStatement(sql)) {
                stmt.setInt(1, forumId);
                stmt.setString(2, userBean.getUsername());
                stmt.setString(3, text);
                stmt.setInt(4, userBean.getUserId());
                stmt.executeUpdate();
                loadComments(forumId); // Refrescar la lista de comentarios
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Failed to create comment", e);
        }
    }

    public void loadComments(int forumId) {
        this.forumId = forumId;
        comments = new ArrayList<>();
        try (Connection connection = DatabaseUtil.getConnection()) {
            String sql = "SELECT * FROM comments WHERE forum_id = ?";
            try (PreparedStatement stmt = connection.prepareStatement(sql)) {
                stmt.setInt(1, forumId);
                try (ResultSet rs = stmt.executeQuery()) {
                    while (rs.next()) {
                        CommentBean comment = new CommentBean();
                        comment.setId(rs.getInt("id"));
                        comment.setForumId(rs.getInt("forum_id"));
                        comment.setText(rs.getString("text"));
                        comment.setUsername(rs.getString("username")); // Asegúrate de que esta línea esté correcta
                        comment.setCreatedAt(rs.getTimestamp("created_at"));
                        comments.add(comment);
                    }
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Failed to load comments", e);
        }
    }

    public void deleteComment(int commentId) {
        try (Connection connection = DatabaseUtil.getConnection()) {
            String sql = "DELETE FROM comments WHERE id = ? AND (created_by = ? OR EXISTS (SELECT 1 FROM users WHERE id = ? AND role = 'ADMIN'))";
            try (PreparedStatement stmt = connection.prepareStatement(sql)) {
                stmt.setInt(1, commentId);
                stmt.setInt(2, userBean.getUserId());
                stmt.setInt(3, userBean.getUserId());
                stmt.executeUpdate();
                loadComments(forumId); // Refrescar la lista de comentarios
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Failed to delete comment", e);
        }
    }
    
        public boolean isCommentOwner(int commentId) {
        FacesContext facesContext = FacesContext.getCurrentInstance();
        HttpSession session = (HttpSession) facesContext.getExternalContext().getSession(false);
        Integer currentUserId = (Integer) session.getAttribute("userId");
        
        //tambien verifica comentario pertenece al usuario actual
        try (Connection connection = DatabaseUtil.getConnection()) {
            String sql = "SELECT created_by FROM comments WHERE id = ?";
            try (PreparedStatement stmt = connection.prepareStatement(sql)) {
                stmt.setInt(1, commentId);
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                        int commentOwnerId = rs.getInt("created_by");
                        return currentUserId != null && currentUserId == commentOwnerId;
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Manejo de excepción
        }
        return false;
    }
}