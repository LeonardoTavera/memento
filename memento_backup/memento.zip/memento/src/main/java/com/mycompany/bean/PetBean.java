package com.mycompany.bean;

import com.mycompany.util.DatabaseUtil;
import jakarta.enterprise.context.SessionScoped;
import jakarta.inject.Named;
import jakarta.faces.context.FacesContext;
import jakarta.servlet.http.Part;
import jakarta.servlet.http.HttpSession;
import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

@Named("petBean")
@SessionScoped
public class PetBean implements Serializable {

    private static final Logger LOGGER = Logger.getLogger(PetBean.class.getName());

    private String petName;
    private java.sql.Date petDeathDate;
    private String petAnimal;
    private String petDescription;
    private Part petImage;
    private String updateMessage;
    private List<Pet> pets = new ArrayList<>();
    private Integer petIdToDelete;

    private String searchQuery;
    private String searchAnimalType;
    private String searchDeathDate;
    private List<Pet> searchResults = new ArrayList<>();

    public static class Pet {
        private Integer id;
        private String name;
        private java.sql.Date deathDate;
        private String animal;
        private String description;
        private String image;

        public Pet(Integer id, String name, java.sql.Date deathDate, String animal, String description, String image) {
            this.id = id;
            this.name = name;
            this.deathDate = deathDate;
            this.animal = animal;
            this.description = description;
            this.image = image;
        }

        public Integer getId() {
            return id;
        }

        public void setId(Integer id) {
            this.id = id;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public Date getDeathDate() {
            return deathDate;
        }

        public void setDeathDate(Date deathDate) {
            this.deathDate = deathDate;
        }

        public String getAnimal() {
            return animal;
        }

        public void setAnimal(String animal) {
            this.animal = animal;
        }

        public String getDescription() {
            return description;
        }

        public void setDescription(String description) {
            this.description = description;
        }

        public String getImage() {
            return image;
        }

        public void setImage(String image) {
            this.image = image;
        }

    }

    public void addPet() {
        try (Connection connection = DatabaseUtil.getConnection()) {
            String sql = "INSERT INTO pets (user_id, name, death_date, animal, description, image) VALUES (?, ?, ?, ?, ?, ?)";
            try (PreparedStatement stmt = connection.prepareStatement(sql)) {
                stmt.setInt(1, getUserId());
                stmt.setString(2, petName);
                stmt.setDate(3, petDeathDate);
                stmt.setString(4, petAnimal);
                stmt.setString(5, petDescription);

                String imagePath = null;
                if (petImage != null && petImage.getSize() > 0) {
                    String fileName = System.currentTimeMillis() + "_" + petImage.getSubmittedFileName();
                    String uploadDir = FacesContext.getCurrentInstance().getExternalContext().getRealPath("/uploads");
                    File uploadFile = new File(uploadDir, fileName);
                    petImage.write(uploadFile.getAbsolutePath());
                    imagePath = "uploads/" + fileName;
                }
                stmt.setString(6, imagePath);

                int rowsInserted = stmt.executeUpdate();
                updateMessage = (rowsInserted > 0) ? "Mascota agregada correctamente!" : "Error al agregar mascota.";
                loadPets();
            }
        } catch (SQLException | IOException e) {
            updateMessage = "Error: " + e.getMessage();
            LOGGER.log(Level.SEVERE, "Error during adding pet", e);
        }
    }

    public void deletePet(Integer petId) {
        try (Connection connection = DatabaseUtil.getConnection()) {
            String sql = "DELETE FROM pets WHERE id = ?";
            try (PreparedStatement stmt = connection.prepareStatement(sql)) {
                stmt.setInt(1, petId);
                int rowsDeleted = stmt.executeUpdate();
                updateMessage = (rowsDeleted > 0) ? "Mascota eliminada correctamente!" : "Error al eliminar mascota.";
                loadPets();
            }
        } catch (SQLException e) {
            updateMessage = "Error: " + e.getMessage();
            LOGGER.log(Level.SEVERE, "Error during deleting pet", e);
        }
    }

    public void loadPets() {
        pets.clear();
        try (Connection connection = DatabaseUtil.getConnection()) {
            String sql = "SELECT id, name, death_date, animal, description, image FROM pets WHERE user_id = ?";
            try (PreparedStatement stmt = connection.prepareStatement(sql)) {
                stmt.setInt(1, getUserId());
                try (ResultSet rs = stmt.executeQuery()) {
                    while (rs.next()) {
                        Pet pet = new Pet(
                            rs.getInt("id"),
                            rs.getString("name"),
                            rs.getDate("death_date"),
                            rs.getString("animal"),
                            rs.getString("description"),
                            rs.getString("image")
                        );
                        pets.add(pet);
                    }
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "SQL Error during loading pets", e);
        }
    }

    private int getUserId() {
        FacesContext context = FacesContext.getCurrentInstance();
        HttpSession session = (HttpSession) context.getExternalContext().getSession(true);
        Integer id = (Integer) session.getAttribute("userId");
        return (id != null) ? id : 0;
    }

    public String getPetName() {
        return petName;
    }

    public void setPetName(String petName) {
        this.petName = petName;
    }

    public java.sql.Date getPetDeathDate() {
        return petDeathDate;
    }

    public void setPetDeathDate(java.sql.Date petDeathDate) {
        this.petDeathDate = petDeathDate;
    }

    public String getPetAnimal() {
        return petAnimal;
    }

    public void setPetAnimal(String petAnimal) {
        this.petAnimal = petAnimal;
    }

    public String getPetDescription() {
        return petDescription;
    }

    public void setPetDescription(String petDescription) {
        this.petDescription = petDescription;
    }

    public Part getPetImage() {
        return petImage;
    }

    public void setPetImage(Part petImage) {
        this.petImage = petImage;
    }

    public String getUpdateMessage() {
        return updateMessage;
    }

    public void setUpdateMessage(String updateMessage) {
        this.updateMessage = updateMessage;
    }

    public List<Pet> getPets() {
        return pets;
    }

    public void setPets(List<Pet> pets) {
        this.pets = pets;
    }

    public Integer getPetIdToDelete() {
        return petIdToDelete;
    }

    public void setPetIdToDelete(Integer petIdToDelete) {
        this.petIdToDelete = petIdToDelete;
    }

    public String getSearchQuery() {
        return searchQuery;
    }

    public void setSearchQuery(String searchQuery) {
        this.searchQuery = searchQuery;
    }

    public String getSearchAnimalType() {
        return searchAnimalType;
    }

    public void setSearchAnimalType(String searchAnimalType) {
        this.searchAnimalType = searchAnimalType;
    }

    public String getSearchDeathDate() {
        return searchDeathDate;
    }

    public void setSearchDeathDate(String searchDeathDate) {
        this.searchDeathDate = searchDeathDate;
    }

    public List<Pet> getSearchResults() {
        return searchResults;
    }

    public void setSearchResults(List<Pet> searchResults) {
        this.searchResults = searchResults;
    }

    public void searchPets() {
        searchResults.clear();
        String sql = "SELECT id, name, death_date, animal, description, image FROM pets WHERE user_id = ? AND name LIKE ? AND animal LIKE ? AND death_date LIKE ?";
        try (Connection connection = DatabaseUtil.getConnection();
             PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, getUserId());
            stmt.setString(2, "%" + searchQuery + "%");
            stmt.setString(3, "%" + searchAnimalType + "%");
            stmt.setString(4, "%" + searchDeathDate + "%");

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Pet pet = new Pet(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getDate("death_date"),
                        rs.getString("animal"),
                        rs.getString("description"),
                        rs.getString("image")
                    );
                    searchResults.add(pet);
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "SQL Error during searching pets", e);
        }
    }
}