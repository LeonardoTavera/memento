package com.mycompany.bean;

import com.mycompany.util.DatabaseUtil;
import jakarta.enterprise.context.SessionScoped;
import jakarta.faces.context.FacesContext;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import jakarta.servlet.http.HttpSession;
import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

@Named("forumBean")
@SessionScoped
public class ForumBean implements Serializable {
    private int id;
    private String title;
    private String description;
    private List<ForumBean> forums;

    @Inject
    private UserBean userBean;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public UserBean getUserBean() {
        return userBean;
    }

    public void setUserBean(UserBean userBean) {
        this.userBean = userBean;
    }

    public List<ForumBean> getForums() {
        if (forums == null) {
            loadForums();
        }
        return forums;
    }

    public void loadForums() {
        forums = new ArrayList<>();
        try (Connection connection = DatabaseUtil.getConnection()) {
            String sql = "SELECT * FROM forums";
            try (PreparedStatement stmt = connection.prepareStatement(sql);
                 ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    ForumBean forum = new ForumBean();
                    forum.setId(rs.getInt("id"));
                    forum.setTitle(rs.getString("title"));
                    forum.setDescription(rs.getString("description"));
                    forums.add(forum);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void createForum() {
        try (Connection connection = DatabaseUtil.getConnection()) {
            String sql = "INSERT INTO forums (title, description, created_by) VALUES (?, ?, ?)";
            try (PreparedStatement stmt = connection.prepareStatement(sql)) {
                stmt.setString(1, title);
                stmt.setString(2, description);
                stmt.setInt(3, userBean.getUserId()); // Aquí se guarda el ID del usuario actual
                stmt.executeUpdate();
                loadForums(); // Refrescar la lista de foros
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteForum(int forumId) {
        try (Connection connection = DatabaseUtil.getConnection()) {
            String sql = "DELETE FROM forums WHERE id = ? AND (created_by = ? OR EXISTS (SELECT 1 FROM users WHERE id = ? AND role = 'ADMIN'))";
            try (PreparedStatement stmt = connection.prepareStatement(sql)) {
                stmt.setInt(1, forumId);
                stmt.setInt(2, userBean.getUserId());
                stmt.setInt(3, userBean.getUserId());
                stmt.executeUpdate();
                loadForums(); // Refrescar la lista de foros
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
        public boolean isForumOwner(int forumId) {
        FacesContext facesContext = FacesContext.getCurrentInstance();
        HttpSession session = (HttpSession) facesContext.getExternalContext().getSession(false);
        Integer currentUserId = (Integer) session.getAttribute("userId");

        //esto va verificar si el foro pertenece al usuario actual
        try (Connection connection = DatabaseUtil.getConnection()) {
            String sql = "SELECT created_by FROM forums WHERE id = ?";
            try (PreparedStatement stmt = connection.prepareStatement(sql)) {
                stmt.setInt(1, forumId);
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                        int forumOwnerId = rs.getInt("created_by");
                        return currentUserId != null && currentUserId == forumOwnerId;
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}