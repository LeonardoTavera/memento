package com.mycompany.bean;

import com.mycompany.util.DatabaseUtil;
import jakarta.enterprise.context.SessionScoped;
import jakarta.inject.Named;
import jakarta.faces.context.FacesContext;
import jakarta.servlet.http.HttpSession;
import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

@Named("userBean")
@SessionScoped
public class UserBean implements Serializable {

    private static final Logger LOGGER = Logger.getLogger(UserBean.class.getName());

    private String username;
    private String password;
    private String email;
    private String description; // Nueva propiedad
    private String gender; // Nueva propiedad
    private String registrationMessage;
    private String loginMessage;
    private String updateMessage;
    private int userId;
    private String role;
    private String searchQuery;
    private List<User> searchResults;

    //clase user
    public static class User {
        private String username;
        private String email;
        private String description;
        private String gender;

        public String getUsername() {
            return username;
        }

        public void setUsername(String username) {
            this.username = username;
        }

        public String getEmail() {
            return email;
        }

        public void setEmail(String email) {
            this.email = email;
        }

        public String getDescription() {
            return description;
        }

        public void setDescription(String description) {
            this.description = description;
        }

        public String getGender() {
            return gender;
        }

        public void setGender(String gender) {
            this.gender = gender;
        }
    }

    public UserBean() {
        searchResults = new ArrayList<>();
    }

    public void register() {
        try (Connection connection = DatabaseUtil.getConnection()) {
            String sql = "INSERT INTO users (username, password, email, description, gender) VALUES (?, ?, ?, ?, ?)";
            try (PreparedStatement stmt = connection.prepareStatement(sql)) {
                stmt.setString(1, username);
                stmt.setString(2, password); // No encriptación
                stmt.setString(3, email);
                stmt.setString(4, description); // Nueva propiedad
                stmt.setString(5, gender); // Nueva propiedad
                int rowsInserted = stmt.executeUpdate();
                registrationMessage = (rowsInserted > 0) ? "Registrado con éxito!" : "Fallo al registrar.";
            }
        } catch (SQLException e) {
            registrationMessage = "Error: " + e.getMessage();
            LOGGER.log(Level.SEVERE, "SQL Error during registration", e);
        }
    }

    public String login() {
        try (Connection connection = DatabaseUtil.getConnection()) {
            String sql = "SELECT id, role, email, description, gender FROM users WHERE username = ? AND password = ?";
            try (PreparedStatement stmt = connection.prepareStatement(sql)) {
                stmt.setString(1, username);
                stmt.setString(2, password); // No encriptación
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                        userId = rs.getInt("id");
                        role = rs.getString("role");
                        email = rs.getString("email");
                        description = rs.getString("description");
                        gender = rs.getString("gender");
                        FacesContext context = FacesContext.getCurrentInstance();
                        HttpSession session = (HttpSession) context.getExternalContext().getSession(true);
                        session.setAttribute("userId", userId);
                        session.setAttribute("role", role);
                        loginMessage = "Login exitoso!";
                        // Redirige al perfil del usuario
                        return "profile.xhtml?faces-redirect=true";
                    } else {
                        loginMessage = "Usuario o contraseña incorrectos.";
                    }
                }
            }
        } catch (SQLException e) {
            loginMessage = "Error: " + e.getMessage();
            LOGGER.log(Level.SEVERE, "SQL Error during login", e);
        }
        //regresa al login
        return null;
    }

    public String updateProfile() {
        try (Connection connection = DatabaseUtil.getConnection()) {
            String sql = "UPDATE users SET email = ?, password = ?, description = ?, gender = ? WHERE username = ?";
            try (PreparedStatement stmt = connection.prepareStatement(sql)) {
                stmt.setString(1, email);
                stmt.setString(2, password); // No encriptación
                stmt.setString(3, description); // Nueva propiedad
                stmt.setString(4, gender); // Nueva propiedad
                stmt.setString(5, username);
                int rowsUpdated = stmt.executeUpdate();
                updateMessage = (rowsUpdated > 0) ? "Perfil actualizado exitosamente!" : "Fallo al actualizar el perfil.";
            }
        } catch (SQLException e) {
            updateMessage = "Error: " + e.getMessage();
            LOGGER.log(Level.SEVERE, "SQL Error during profile update", e);
        }
        //en la misma página
        return null;
    }

    public String logout() {
        FacesContext facesContext = FacesContext.getCurrentInstance();
        if (facesContext != null) {
            HttpSession session = (HttpSession) facesContext.getExternalContext().getSession(false);
            if (session != null) {
                session.invalidate();
                // Redirige al login después de desloguearse
                return "login.xhtml?faces-redirect=true";
            }
        }
        return null;
    }

    public void searchUsers() {
        searchResults.clear();
        if (searchQuery != null && !searchQuery.trim().isEmpty()) {
            try (Connection connection = DatabaseUtil.getConnection()) {
                String sql = "SELECT username, email, description, gender FROM users WHERE username LIKE ? OR email LIKE ?";
                try (PreparedStatement stmt = connection.prepareStatement(sql)) {
                    stmt.setString(1, "%" + searchQuery + "%");
                    stmt.setString(2, "%" + searchQuery + "%");
                    try (ResultSet rs = stmt.executeQuery()) {
                        while (rs.next()) {
                            User user = new User();
                            user.setUsername(rs.getString("username"));
                            user.setEmail(rs.getString("email"));
                            user.setDescription(rs.getString("description"));
                            user.setGender(rs.getString("gender"));
                            searchResults.add(user);
                        }
                    }
                }
            } catch (SQLException e) {
                LOGGER.log(Level.SEVERE, "SQL Error during user search", e);
            }
        }
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getRegistrationMessage() {
        return registrationMessage;
    }

    public void setRegistrationMessage(String registrationMessage) {
        this.registrationMessage = registrationMessage;
    }

    public String getLoginMessage() {
        return loginMessage;
    }

    public void setLoginMessage(String loginMessage) {
        this.loginMessage = loginMessage;
    }

    public String getUpdateMessage() {
        return updateMessage;
    }

    public void setUpdateMessage(String updateMessage) {
        this.updateMessage = updateMessage;
    }

    public int getUserId() {
        FacesContext context = FacesContext.getCurrentInstance();
        HttpSession session = (HttpSession) context.getExternalContext().getSession(true);
        Integer id = (Integer) session.getAttribute("userId");
        return (id != null) ? id : 0;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getRole() {
        FacesContext context = FacesContext.getCurrentInstance();
        HttpSession session = (HttpSession) context.getExternalContext().getSession(true);
        return (String) session.getAttribute("role");
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getSearchQuery() {
        return searchQuery;
    }

    public void setSearchQuery(String searchQuery) {
        this.searchQuery = searchQuery;
    }

    public List<User> getSearchResults() {
        return searchResults;
    }

    public void setSearchResults(List<User> searchResults) {
        this.searchResults = searchResults;
    }
}