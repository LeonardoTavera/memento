package com.mycompany.bean;

import jakarta.faces.view.ViewScoped;
import jakarta.inject.Named;
import java.io.Serializable;

@Named
@ViewScoped
public class TestBean implements Serializable {
    private static final long serialVersionUID = 1L;
    private String message = "Hello World";

    public String getMessage() {
        return message;
    }
}