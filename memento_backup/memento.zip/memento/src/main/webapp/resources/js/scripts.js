let currentIndex = 0;
const intervalTime = 3000; // Tiempo en milisegundos para cambiar la diapositiva automáticamente

function showSlide(index) {
    const items = document.querySelectorAll('.carousel-item');
    const totalSlides = items.length;
    if (index >= totalSlides) {
        currentIndex = 0;
    } else if (index < 0) {
        currentIndex = totalSlides - 1;
    } else {
        currentIndex = index;
    }
    const offset = -currentIndex * 100;
    document.querySelector('.carousel-items').style.transform = `translateX(${offset}%)`;
}

function nextSlide() {
    showSlide(currentIndex + 1);
}

function prevSlide() {
    showSlide(currentIndex - 1);
}

// Cambia la diapositiva automáticamente
let autoSlide = setInterval(nextSlide, intervalTime);

document.addEventListener('DOMContentLoaded', () => {
    showSlide(currentIndex);
});